<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mobil;
use App\Models\pembeli;
use App\Models\beli_cash;

class CashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.cash.index', [
            'beli_cash' => beli_cash::get(),
            'mobil' => mobil::all(),
        'pembeli' => pembeli::all()
        ]);



    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.cash.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request ->validate([
            'ktp_pembeli' => 'required',
            'kode_mobil' => 'required',
            'cash_bayar' => 'required',
            'cash_tgl' => 'required'
        ]);
        $last_id = beli_cash::select('kode_cash')->orderBy('created_at','desc')->first();

        $kode_cash = ($last_id==null)?sprintf('C%08d',1)
                        :sprintf('C%08d',substr($last_id->kode_cash,1,8)+1);

        $validated['kode_cash'] = $kode_cash;

        // dd($request);
        $input = beli_cash::create($validated);

        if($input) return redirect('dashboard/cash')->with('success', 'Data cash berhasil diinput');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
