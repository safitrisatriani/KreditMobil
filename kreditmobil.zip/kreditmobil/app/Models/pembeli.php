<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pembeli extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
    protected $fillable = [
        'ktp_pembeli',
        'nama_pembeli',
        'alamat_pembeli',
        'telp_pembeli'
    ];
}
