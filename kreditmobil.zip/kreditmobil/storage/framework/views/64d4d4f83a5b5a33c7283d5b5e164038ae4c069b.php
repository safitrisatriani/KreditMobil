<div class="card">
    <div class="card-header">
        Data Pembeli
    </div>
    <div class="card-body">
        <div>
            <button type="button" class="btn btn-primary" data-toggle="modal"
            data-target="#pilihPelangganModal">
                Pilih Pelanggan
            </button>
        </div>
        <div class="data-pelanggan">

        </div>
    </div>
</div>

<div class="modal fade" id="pilihPelangganModel" tabindex="-1"
role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLontTitle">Plih Pelanggan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <table id="tbl-pelanggan" class="table table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>No. KTP</th>
                        <th>Nama</th>
                        <th>No. Hp</th>
                        <th>Pilih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pembelis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembeli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i = (isset($i)?++$i:$i=1)); ?></td>
                        <td><?php echo e($pembeli->ktp_pembeli); ?></td>
                        <td><?php echo e($pembeli->nama_pembeli); ?></td>
                        <td><?php echo e($pembeli->telp_pembeli); ?></td>
                        <td><button>Pilih</button></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger">Save changes</button>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\applications\salman-cicilan\resources\views/dashboard/cash/pembeli.blade.php ENDPATH**/ ?>