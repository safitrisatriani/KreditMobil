<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-danger">
    <div class="container">
      <a class="navbar-brand text-danger" href="/"><i class="bi bi-trash text-danger"></i> <b>Fana</b></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active === "home") ? 'active' : ''); ?>" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active === "product") ? 'active' : ''); ?>" href="/product">Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(($active === "promo") ? 'active' : ''); ?>" href="/promo">Promo</a>
          </li>
          <li>
            <div class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              More
              </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">Help Center</a></li>
                  <li><a class="dropdown-item" href="#">About</a></li>
                </ul>
            </div>
          </li>
        </ul>

        <ul class="navbar-nav ms-auto">
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Welcome back, <?php echo e(auth()->user()->name); ?>

                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="/dashboard"><i class="bi bi-layout-text-sidebar-reverse"></i> My Dashboard</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li>
                          <form action="/logout" method="POST">
                            <?php echo csrf_field(); ?>
                              <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right"></i> Logout</button>
                          </form>
                      </li>
                </ul>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a href="/login" class="nav-link <?php echo e(($active === "login") ? 'active' : ''); ?>"><i class="bi bi-box-arrow-in-right"></i> Login</a>
            </li>
            <?php endif; ?>
        </ul>


      </div>
    </div>
  </nav>
  <!-- Navbar -->

  
  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
    <div class="carousel-item active">
        <img src="https://source.unsplash.com/1200x400/?cars" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
        <img src="https://source.unsplash.com/1200x400/?audi" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
        <img src="https://source.unsplash.com/1200x400/?bmw" class="d-block w-100" alt="...">
    </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
    </button>
</div>

<?php /**PATH C:\applications\salman-cicilan\resources\views/partials/navbar2.blade.php ENDPATH**/ ?>