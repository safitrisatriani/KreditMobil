<div class="card">
    <div class="card-header">
        Data Mobil &nbsp;
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pilihMobilModal">
            Pilih Mobil
        </button>
    </div>
    <div class="card-body">
        <div class="data-mobil">

            <div class=" col-lg-12 mt-3 mb-3">
                <div class="mb-3">
                    <label for="kode_mobil" class="form-label">Kode Mobil</label>
                    <input type="text" class="form-control" id="v-kode_mobil" name="kode_mobil">
                </div>
                <div class="mb-3">
                    <label for="merek" class="form-label">Merek Mobil</label>
                    <input type="text" class="form-control" id="v-merek" name="merek">
                </div>
                <div class="mb-3">
                    <label for="tipe" class="form-label">Tipe Mobil</label>
                    <input type="text" class="form-control" id="v-tipe" name="tipe">
                </div>
                <div class="mb-3">
                    <label for="warna" class="form-label">Warna Mobil</label>
                    <input type="text" class="form-control" id="v-warna" name="warna">
                </div>
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga Mobil</label>
                    <input type="text" class="form-control" id="v-harga" name="harga">
                </div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="pilihMobilModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" id="exampleModalLabel">Plih Mobil</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <table id="tbl-mobil" class="table table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Kode Mobil</th>
                        <th>Merk</th>
                        <th>Tipe</th>
                        <th>Warna</th>
                        <th>Harga</th>
                        <th>Pilih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i = (isset($i)?++$i:$i=1)); ?></td>
                        <td><?php echo e($mobil->kode_mobil); ?></td>
                        <td><?php echo e($mobil->merek_mobil); ?></td>
                        <td><?php echo e($mobil->tipe_mobil); ?></td>
                        <td><?php echo e($mobil->warna_mobil); ?></td>
                        <td><?php echo e($mobil->harga_mobil); ?></td>
                        <td><button class="pilih-mobil">Pilih</button></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\aplikasi\salman-cicilan\resources\views/dashboard/cash/mobil.blade.php ENDPATH**/ ?>