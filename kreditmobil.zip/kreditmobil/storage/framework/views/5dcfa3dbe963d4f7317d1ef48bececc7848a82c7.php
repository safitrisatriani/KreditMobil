<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse" style="background-color: pink">
    <div class="position-sticky pt-3">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">
            <i class="bi bi-house-door"></i>
            Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/mobil') ? 'active' : ''); ?>" href="/dashboard/mobil">
            <span><i class="bi bi-clipboard"></i></span>
            Mobil
          </a>
        </li>
      </ul>
    </div>
</nav>
<?php /**PATH D:\applications\salman-cicilan\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>