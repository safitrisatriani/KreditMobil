<div class="card">
    <div class="card-header">
         Pembayaran &nbsp;
    </div>
    <div class="card-body">
        <div class="data-mobil">
            <table class="table table-bordered">
                <tr>
                    <td class="table-warning" width="50%">Tanggal:</td>
                    <td><input type="date" class="form-control" name="cash_tgl" id="cash_tgl" required></td>
                </tr>
                <tr>
                    <td class="table-warning" width="50%">Uang yang dibayarkan:</td>
                    <td><input type="text" class="form-control" name="cash_bayar" id="cash_bayar" required></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\aplikasi\salman-cicilan\resources\views/dashboard/cash/cash.blade.php ENDPATH**/ ?>