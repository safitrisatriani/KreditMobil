<?php $__env->startSection('container'); ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Buyers Data</h1>
    </div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success text-center" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="table-responsive col-lg-8">
        <a href="/dashboard/pembeli/create" class="btn btn-dark btn-outline-secondart border-0 mb-3 text-decoration-none">Create Data</a>
        <table id="tbl-pelanggan" class="table table-striped table-lg">
          <thead>
            <tr>
              <th scope="col">No</th>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Address</th>
              <th scope="col">Phone Number</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $pembelis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembeli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pembeli->ktp_pembeli); ?></td>
                    <td><?php echo e($pembeli->nama_pembeli); ?></td>
                    <td><?php echo e($pembeli->alamat_pembeli); ?></td>
                    <td><?php echo e($pembeli->telp_pembeli); ?></td>
                    <td>
                        <a href="/dashboard/pembeli/show" class="badge bg-info"><i class="bi bi-eye"></i></a>
                        <a href="/dashboard/pembeli/<?php echo e($pembeli->id); ?>edit" class="badge bg-warning"><i class="bi bi-pencil-square"></i></a>
                        <form action="<?php echo e(url('dashboard/pembeli/'.$pembeli->id)); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="badge bg-danger border-0" onclick="return confirm('Are you sure want to delete this data?')"><i class="bi bi-x-circle"></i></button>
                        </form>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Applications\kreditmobil\resources\views/dashboard/pembeli/index.blade.php ENDPATH**/ ?>