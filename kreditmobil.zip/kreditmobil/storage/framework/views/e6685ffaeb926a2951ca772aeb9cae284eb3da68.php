<div class="card">
    <div class="card-header">
        Data Pembeli &nbsp;
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pilihPelangganModal">
            Pilih Pelanggan
        </button>
    </div>
    <div class="card-body">
        <div class="data-pelanggan">

            <div class=" col-lg-12 mt-3 mb-3">
                <div class="mb-3">
                    <label for="ktp" class="form-label">No Ktp</label>
                    <input type="text" class="form-control" id="v-ktp" name="ktp_pembeli">
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="v-nama" name="nama">
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control" id="v-alamat" name="alamat">
                </div>
                <div class="mb-3">
                    <label for="telp" class="form-label">Telepon</label>
                    <input type="text" class="form-control" id="v-telp" name="telp">
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="pilihPelangganModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-dark" id="exampleModalLabel">Plih Pelanggan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <table id="tbl-pelanggan" class="table table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>No. KTP</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No. Hp</th>
                        <th>Pilih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pembeli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembeli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i = (isset($i)?++$i:$i=1)); ?></td>
                        <td><?php echo e($pembeli->ktp_pembeli); ?></td>
                        <td><?php echo e($pembeli->nama_pembeli); ?></td>
                        <td><?php echo e($pembeli->alamat_pembeli); ?></td>
                        <td><?php echo e($pembeli->telp_pembeli); ?></td>
                        <td><button class="pilih-pelanggan">Pilih</button></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\aplikasi\salman-cicilan\resources\views/dashboard/cash/pembeli.blade.php ENDPATH**/ ?>