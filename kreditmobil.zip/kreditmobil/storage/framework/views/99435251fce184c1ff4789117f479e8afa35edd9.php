<?php $__env->startSection('tubuh'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Applications\kreditmobil\resources\views/index.blade.php ENDPATH**/ ?>