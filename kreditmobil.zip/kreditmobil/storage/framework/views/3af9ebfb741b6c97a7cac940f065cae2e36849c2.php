<?php $__env->startSection('container'); ?>

<div class="card bg-secondary">
    <div class="card-header">
        <h3 class="card-title">Pembelian Cash</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-cardwidget="colapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <div class="card-body">
        <div style="margin-top: 20px">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert" id="error-alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">$times;</span>
                    </button>
                    <ul>
                        <?php $__currentLoopData = @errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
        <?php echo $__env->make('dashboard.cash.pembeli', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        
    </div>
    </div>
    <div class="card-footer">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(function(){
        $('tbl-pelanggan').DataTable();
    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\applications\salman-cicilan\resources\views/dashboard/cash/index.blade.php ENDPATH**/ ?>