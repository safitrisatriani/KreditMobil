<?php $__env->startSection('container'); ?>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Mobil</h1>
    </div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success text-center" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <a href="/dashboard/mobil/create" class="btn btn-dark border-0 mb-3 text-decoration-none">Create new post</a>
        <table class="table table-striped table-md text-light">
          <thead>
            <tr class="text-light">
              <th scope="col">No</th>
              <th scope="col">Kode Mobil</th>
              <th scope="col">Merk</th>
              <th scope="col">Tipe</th>
              <th scope="col">Warna</th>
              <th scope="col">Harga</th>
              <th scope="col">Gambar</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $mobils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-light">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($mobil->kode_mobil); ?></td>
                    <td><?php echo e($mobil->merek_mobil); ?></td>
                    <td><?php echo e($mobil->tipe_mobil); ?></td>
                    <td><?php echo e($mobil->warna_mobil); ?></td>
                    <td><?php echo e($mobil->harga_mobil); ?></td>
                    <td><img src="<?php echo e(asset('storage/' . $mobil->gambar_mobil)); ?>" alt="" width="72" height="57"> </td>
                    <td>
                        <a href="/dashboard/mobil/<?php echo e($mobil->id); ?>/edit" class="btn btn-warning text-light">Edit</a>
                        <form action="<?php echo e(url('dashboard/mobil/'.$mobil->id)); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-danger border-0" onclick="return confirm('Anda Yakin?')">Delete</button>
                        </form>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\salman-cicilan\resources\views/dashboard/mobil/index.blade.php ENDPATH**/ ?>