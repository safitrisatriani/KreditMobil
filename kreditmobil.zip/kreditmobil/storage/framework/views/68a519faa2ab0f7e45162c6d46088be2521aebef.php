<?php $__env->startSection('container'); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Pembelian Cash</h3>
        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-cardwidget="colapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <div class="card-body">
        <div style="margin-top: 20px">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert" id="error-alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">$times;</span>
                    </button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div>
    <form action="<?php echo e(route('cash.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('dashboard.cash.pembeli', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dashboard.cash.mobil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dashboard.cash.cash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="text-align:right">
            <button class="btn btn-primary" type="submit">Bayar</button>
        </div>
    </form>
    </div>
    <div class="card-footer">

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(function(){
        $('#tbl-pelanggan').DataTable();
        $('#tbl-mobil').DataTable();

        $('#tbl-pelanggan').on('click', '.pilih-pelanggan', function(){
            let ele = $(this).closest('tr');
            let ktp = ele.find('td:eq(1)').text();
            let nama = ele.find('td:eq(2)').text();
            let alamat = ele.find('td:eq(3)').text();
            let telp = ele.find('td:eq(4)').text();
            $('#v-ktp').val(ktp)
            $('#v-nama').val(nama)
            $('#v-alamat').val(alamat)
            $('#v-telp').val(telp)
            $('#pilihPelangganModal').modal('hide')
        });

        $('#tbl-mobil').on('click', '.pilih-mobil', function(){
            let ele = $(this).closest('tr');
            let kode_mobil = ele.find('td:eq(1)').text();
            let merek = ele.find('td:eq(2)').text();
            let tipe = ele.find('td:eq(3)').text();
            let warna = ele.find('td:eq(4)').text();
            let harga = ele.find('td:eq(5)').text();
            $('#v-kode_mobil').val(kode_mobil)
            $('#v-merek').val(merek)
            $('#v-tipe').val(tipe)
            $('#v-warna').val(warna)
            $('#v-harga').val(harga)
            $('#pilihMobilModal').modal('hide')
        });

        Date.prototype.toDateInputValue = (function() {
        var local = new Date(this);
        local.setMinutes(this.getMinutes() - this.getTimezoneOffset());
        return local.toJSON().slice(0,10);
        });

        $('#cash_tgl').val(new Date().toDateInputValue());

        $('#f-cash').submit(function(e){
            e.preventDefault();
            if($('v-ktp').val() == ""){
                alert('data pelanggan belum dipilih')

            }else if($('#v-kode_mobil').val() == ""){
                alert('data mobil belum dipilih')

            }else{
                e.currentTarget.submit()
            }
        })

    })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aplikasi\salman-cicilan\resources\views/dashboard/cash/index.blade.php ENDPATH**/ ?>